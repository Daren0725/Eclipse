package de.hwg_lu.bwi.bean;

public class RezeptBean {
	String username;
	String email;
	String vorname;
	String nachname;
	String Geburtstag;
	String ernaerungsart;
	
	
	public RezeptBean(){
		
	}
	
	
}
