package de.hwg_lu.bwi.jdbc;

import java.sql.SQLException;

public class PostgreSQLAccess extends JDBCAccess {

	public PostgreSQLAccess() throws NoConnectionException {
		super();
	}
	public void setDBParms(){
		dbDrivername = "org.postgresql.Driver";
		dbURL        = "jdbc:postgresql://143.93.200.243:5435/BWUEBDB";
		dbUser       = "user1";
		dbPassword   = "pgusers";
		dbURL        = "jdbc:postgresql://localhost:5432/BWUEBDB";
		dbUser       = "postgres";
		dbPassword   = "postgres";
		dbSchema     = "bwi520_636293";
		
	}
	public void setSchema() throws NoConnectionException {
		this.setSchema(dbSchema);
	}
	public PostgreSQLAccess(String currentSchema) throws NoConnectionException, SQLException {
		super();
		this.createSchemaIfNotExists(currentSchema);
		this.setSchema(currentSchema);
	}
	public void createSchemaIfNotExists(String currentSchema) throws SQLException{
		String sql = "create schema if not exists " + currentSchema;
		System.out.println(sql);
		dbConn.prepareStatement(sql).execute();
		System.out.println("Schema " + dbSchema + " muesste jetzt existieren");
	}
	public void setSchema(String currentSchema) throws NoConnectionException {
		try{
			String sql = "SET SCHEMA '" + currentSchema + "'";
			System.out.println(sql);
			dbConn.createStatement().execute(sql);
			System.out.println("Schema " + currentSchema + " gesetzt");
		}catch(SQLException se){
			se.printStackTrace();
			throw new NoConnectionException();
		}
	}
	public static void main(String[] args) throws NoConnectionException { 
		new PostgreSQLAccess().getConnection();
	}
}